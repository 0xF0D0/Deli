//
//  Version.swift
//  Deli
//

struct Version {
    let value: String

    static let current = Version(value: "0.7.0")
}