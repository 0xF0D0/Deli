//
//  InheritanceInfo.swift
//  deli
//
//  Created by Kawoou on 2018. 4. 13..
//

import Foundation

struct InheritanceInfo {
    let name: String
    let types: [String]
    let structure: Structure
    let content: String
}
