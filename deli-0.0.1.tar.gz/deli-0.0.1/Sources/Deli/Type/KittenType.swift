//
//  KittenType.swift
//  Deli
//

import SourceKittenFramework

typealias KittenType = [String: SourceKitRepresentable]
typealias KittenStructure = SourceKittenFramework.Structure
